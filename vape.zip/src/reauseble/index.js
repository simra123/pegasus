import Loader from "./loader";
export { Loader };
