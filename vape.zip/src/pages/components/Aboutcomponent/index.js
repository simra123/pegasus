export {default as Aboutsec1 } from './Aboutsec1';
export {default as Aboutsec2 } from './Aboutsec2';