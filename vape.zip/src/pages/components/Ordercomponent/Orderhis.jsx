import React from "react";
import { Link } from "react-router-dom";
// import '../../Orderdetail';
import ab1 from "../../../assets/images/ab1.jpg";

const Orderhis = () => {
  return (
    <>
      <section className="sec sec2 orderhis_sec">
        <div className="container">
          <div className="inner_wrap">
            <h2>Now <span>1</span></h2>
            <div className="order_list">
              <ul>
                <li>
                  <div className="top_bar">
                    <p>Pegasus Order on, <span className="date_wrap">Jan 8,2022</span> - <span>09:00 A.M</span></p>
                  </div>
                  <div className="mid_bar">
                    <div className="img_wrap">
                      <img src={ab1} alt="no" />
                    </div>
                    <div className="order_decs">
                      <h4 className="status">Order Pending</h4>
                      <h5>360 Vape Pot (1)</h5>
                      <p><span>$</span>199</p>
                    </div>
                  </div>
                  <div className="bot_wrap">
                    <Link to="/orderdetail"> View</Link>
                  </div>
                </li>
              </ul>
            </div>
            <br />
            <h2>Past Orders</h2>
          </div>
        </div>
      </section>
    </>
  );
};

export default Orderhis;
