import React from 'react'

const Orderdetails = () => {
  return (
    <>
    </>
  )
}

export default Orderdetails