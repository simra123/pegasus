export {default as Productdecs } from './Productdecs';
export {default as Recentviewed } from './Recentviewed';