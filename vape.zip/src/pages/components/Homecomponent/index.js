export {default as Sec1 } from './sec1';
export {default as Sec2 } from './sec2';
export {default as Sec3 } from './sec3';
export {default as Sec4 } from './sec4';
export {default as Sec5 } from './sec5';