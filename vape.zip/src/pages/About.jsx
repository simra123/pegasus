import React from "react";
import {Aboutsec1, Aboutsec2} from './components/Aboutcomponent';

const About = () => {
  return (
    <>
      <div className="content_wrap">
        <Aboutsec1 />
        <Aboutsec2 />
      </div>
    </>
  );
};

export default About;