import React from 'react'
import {Orderdetails} from './components/Ordercomponent';

const Orderdetail = () => {
  return (
    <>
      <div className='content_wrap'>
        <Orderdetails />
      </div>
    </>
  )
}

export default Orderdetail