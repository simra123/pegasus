export {default as Createnewpass } from './Createnewpass';
export {default as Forgotpassword } from './Forgotpassword';
export {default as Loginform } from './Login';
export {default as Registerform } from './Registerform';
export {default as Verifyemail } from './Verifyemail';
export {default as Sellerform } from './Sellerform';